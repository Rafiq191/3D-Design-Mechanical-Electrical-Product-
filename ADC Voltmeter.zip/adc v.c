#include "stm32f1xx_hal.h" // Include the HAL library instead of stm32f10x.h
#include "LiquidCrystal.h"

// Pin definitions using HAL
#define rs_pin GPIO_PIN_11
#define en_pin GPIO_PIN_10
#define d4_pin GPIO_PIN_0
#define d5_pin GPIO_PIN_1
#define d6_pin GPIO_PIN_7
#define d7_pin GPIO_PIN_6

// Create an instance of the LiquidCrystal class
LiquidCrystal lcd(rs_pin, en_pin, d4_pin, d5_pin, d6_pin, d7_pin);

// Analog input pin
#define analogInput_pin GPIO_PIN_0

void setup()
{
    // Initialize the LCD
    lcd.begin(16, 2);
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Electronics Hub");
    lcd.setCursor(0, 1);
    lcd.print(" ADC in STM32 ");
    HAL_Delay(2000); // Use HAL_Delay instead of delay
    lcd.clear();
}

void loop()
{
    // Read analog value
    int analogVal = analogRead(analogInput_pin);
    float inputVoltage = (float)analogVal / 4096 * 3.3;

    lcd.setCursor(0, 0);
    lcd.print("ADC Value:");
    lcd.print(analogVal);
    lcd.setCursor(0, 1);
    lcd.print("Voltage:");
    lcd.print(inputVoltage, 2); // Display voltage with 2 decimal places
    HAL_Delay(1000); // Delay for better readability
    lcd.clear();
}
